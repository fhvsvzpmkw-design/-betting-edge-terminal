LOU VEGA HOTLINE ASSET PACK

Unzip this file, then upload/replace the files at these exact repository paths:

data/characters/lou-vega.json
docs/source-material/lou-vega-canon-language-guide.md
docs/source-material/lou-vega-scene-bank.md
tests/lou-vega-v2.test.mjs

The locked Vegas by the Slice v2 shell and Lou avatar were not changed by this update.
